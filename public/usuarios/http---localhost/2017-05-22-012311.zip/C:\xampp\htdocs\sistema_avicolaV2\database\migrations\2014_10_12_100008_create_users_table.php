<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('foto')->nullable();
            $table->string('email')->unique();
            $table->string('password');
            $table->char('estado');
            $table->integer('idEmpleado')->unsigned()->nullable();
            $table->string('idEmpresa');
            $table->char('tipoUser');
            $table->char('privilegio')->nullable();
            $table->char('visible');
            $table->rememberToken();
            $table->timestamps();

            $table->foreign('idEmpleado')->references('id')->on('persona');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
