<?php

namespace sisAvicola\Http\Controllers;

use Illuminate\Http\Request;

class UsuarioController extends Controller
{
    //
}
